/*************************************************************************
	> File Name: chash.h
	> Author: 
	> Mail: 
	> Created Time: 2018年07月21日 星期六 23时14分31秒
 ************************************************************************/

#ifndef _CHASH_H
#define _CHASH_H
#endif

#include<map>
#include<vector>
#include<iostream>
#include"./md5.h"
#include<string>
using namespace std;
class Md5{
  public:
    string get_md5(const string &str) {
      return MD5(str).toStr();
    }
};

struct Node
{
    int vnode_count;
    string main_msg;  //repsent IP
    vector<string> vnode_msg;  //MD5(IP#I)
    string local_key;  //repsent MD5(IP)
    Node(string key,const string &msg);
    Node(){}
};
Node::Node(string key,const string &msg):local_key(key),main_msg(msg)
{
    
}

class RealNode
{
 public:
   typedef string (*hock)(const string &,int );
    map<string,Node>  node;  //node store md5#i md5(ip)
    static hock hock_info;
    string add_node(const string &msg);  //add original Node
    string add_vnode(const string key,int flag);
    static void setHock(hock fun);
    vector<string> del_node(const string &msg);
    string get_msg(const string &key);  //search key's read; msg
};

RealNode::hock RealNode::RealNode::hock_info=NULL;


class CHash
{
    public:

   CHash(int num,const vector<string> &msg);
    //relation store the relationship bettewn vndoe's and ser ip
    void add_serve(const string &msg);
    void del_server(const string &msg);
    string find(const string &msg);
    void show_servers();
    private:
    map<string,string> relation;
    RealNode rnodes;
    int server_count;
};

