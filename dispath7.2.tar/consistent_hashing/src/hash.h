#include <iostream>
#include <map>
#include <list>
#include <vector>
#include <string>
#include "./md5.h"

using std::map;
using std::vector;
using std::list;
using std::string;

class Md5{
  public:
    string get_md5(const string &str) {
      return MD5(str).toStr();
    }
};

template <typename T>
class Nodes{
  public:
    /*This actual key*/
    string local_key;
    /*the virtual nodes keys*/
    vector<string> others;
    T main_msg;
    Nodes(string key, const T& msg);
    Nodes(){}
};

template <typename T>
class ActualNodes{
  public:
    typedef string (*Construct)(const T&, int);
    map<string, Nodes<T> > nodes;
    static Construct constructMsg; 
    /*add node and return key*/
    string add_node(const T& msg);
    string add_vnode(string key, int num);
    static void setFunc(Construct cfun);
    vector<string> del_node(const T&msg);
    T get_msg(const string &key);
};
template <typename T>
typename ActualNodes<T>::Construct ActualNodes<T>::constructMsg = NULL;
/****************************************************/
template <typename T>
class CHash{
  private:
    /*The key is cur node id, the value is the true cache*/
    map<string, string> hash_map;
    /*actual nodes*/
    ActualNodes<T> anodes;
    int init_num;
  public:
    CHash(int num, const vector<T> &msg);
    void add_server(const T&msg);
    void del_server(const T&msg);
    T find(const T&msg);
    void show_servers();
};
/******************************************************/
/*Nodes*/
template <typename T>
Nodes<T>::Nodes(string key, const T& msg)
  :local_key(key), main_msg(msg)
{}

/******************************************************/
/*ActualNodes*/
template <typename T>
T ActualNodes<T>::get_msg(const string &key) {
  return nodes[key].main_msg;
}
template <typename T>
string ActualNodes<T>::add_node(const T&msg) {
  string res_key = Md5().get_md5(msg);
  nodes[res_key] = Nodes<T>(res_key, msg);
  return res_key;
}

template <typename T>
string ActualNodes<T>::add_vnode(string key, int num) {
  const T& new_msg = ActualNodes<T>::constructMsg(nodes[key].main_msg, num);
  string new_key = Md5().get_md5(new_msg);
  nodes[key].others.push_back(new_key);
  return new_key;
}
template <typename T>
void ActualNodes<T>::setFunc(Construct cfun) {
  constructMsg = cfun;
}
template <typename T> 
vector<string> ActualNodes<T>::del_node(const T&msg) {
  string k = Md5().get_md5(msg);
  typename map<string, Nodes<T> >::iterator it = nodes.find(k);
  vector<string> resvec = it->others;
  resvec.push_back(k);
  nodes.erase(it);
  return resvec;
}
/******************************************************/
/*CHash*/
template <typename T>
CHash<T>::CHash(int num, const vector<T> &msg)
  :init_num(num)

{
  if (num != msg.size()) return;
  string key;
  string new_key;
  int vnode_num = 3;
  typename vector<T>::const_iterator cit = msg.begin();
  for (; cit!=msg.end(); ++cit) {
    key = anodes.add_node(*cit);
    hash_map[key]= key;

    for (int i=0; i<vnode_num; ++i) {
      new_key = anodes.add_vnode(key, i);
      hash_map[new_key] = key;
    }
  }
}
template <typename T>
void CHash<T>::add_server(const T& msg) {
  string key = anodes.add_node(msg);
  hash_map[key] = key;
  string new_key;
  for (int i=0; i<3; ++i) {
    new_key = anodes.add_vnode(key, i);
    hash_map[new_key] = key;
  }
}
template <typename T>
void CHash<T>::del_server(const T& msg) {
  vector<string> vnode_key = anodes.del_node(msg);
  for (int i=0; i<vnode_key.size(); ++i) {
    hash_map.erase(hash_map.find(vnode_key[i]));
  }
}
template <typename T>
T CHash<T>::find(const T& msg) {
  string dest_key = Md5().get_md5(msg);
  typename map<string, string>::const_iterator cit = hash_map.begin();
  for (; cit != hash_map.end(); ++cit) {
    if (cit->first > dest_key) {
      break;
    }
  }
  if (cit == hash_map.end()) {
    cit = hash_map.begin();
  }
  return anodes.get_msg(cit->second);
}
template <typename T>
void CHash<T>::show_servers() {
  std::cout << "AllNodes is:" << std::endl;
  typename map<string, string>::const_iterator cit = hash_map.begin();
  for (; cit!=hash_map.end(); ++cit) {
    std::cout << cit->first << "====>>" << anodes.get_msg(cit->second) << std::endl;
  }

}
